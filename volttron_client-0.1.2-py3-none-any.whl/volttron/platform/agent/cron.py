__import__('warnings').warn(
    'Module {} is deprecated in favor of volttron.platform.scheduling '
    'and will be removed in a future version.'.format( __name__),
    DeprecationWarning)
